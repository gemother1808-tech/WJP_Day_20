package com.cdac.entities;

public enum OrderStatus {
	NEW, PROCESSING, DELIVERED, CANCELLED
}
